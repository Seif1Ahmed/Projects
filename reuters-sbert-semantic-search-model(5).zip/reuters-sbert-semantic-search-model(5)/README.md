---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:1000
- loss:CosineSimilarityLoss
base_model: sentence-transformers/all-MiniLM-L6-v2
widget:
- source_sentence: gordon make bid acquire pagecorp lt pgoa lt gordon investment corp
    said plan make offer acquire pagecorp inc 's class class share 25 dlrs cash per
    share bid conditional upon examination gordon business affair pagecorp 45 day
    ending december 1987 proposed offer would condition upon ainimum number share
    tendered gordon said say minimum meanwhile pagecorp said agreed grant gordon option
    purchaser 900 000 class share 25 dlrs per share exercisable gordon make acquisition
    bid december 1987 third party begin takeover december 31 1987 pagecorp also said
    class shareholder agreed deposit class share gordon proceeds offer
  sentences:
  - bally lt bly seen selling health unit bally manufacturing corp 's proposed public
    offering 24 pct health tennis corp unit seen first step towards sale entire unit
    analyst said longer term horizon bally want concentrate gaming business said analyst
    dennis forst seidler amdec security inc last week bally said considering sale
    another non casino unit six flag amusement park unit analyst said could fetch
    300 mln dlrs bally spokesman bill peltier said company currently hard plan sell
    health club company long term 'll wait see offering go bally 's biggest revenue
    producer health club unit 1986 operating income 60 mln dlrs revenue 456 mln dlrs
    28 pct bally 's revenue analyst estimate unit could sold 300 500 mln dlrs analyst
    said bally 's decision offer share unit could first step selling would seem obvious
    offering would decrease health club unit 's debt increase cash flow operating
    income making attractive buy third party steven eisenberg bear stearns said monday
    bally said filed security exchange commission initial offering 24 pct mln share
    unit 's common stock 13 15 dlrs share half proceeds 40 mln dlrs used reduce parent
    bally manufacturing 's debt swelled billion dlrs due recent hotel acquisition
    purchase share donald trump threatened hostile takeover according bally treasurer
    paul johnson remaining proceeds stock offering separate offering 50 mln dlrs 20
    year convertible subordinated debt would used repay 75 mln dlrs short term senior
    bank debt health chain unit bally spokesperson said analyst said bally 's health
    club unit 's profit remained strong skeptical industry 's long range prospect
    fitness club industry last 10 year grown tremendously question whether fad permanent
    part lifestyle said eisenberg bear stearns analyst said fitness club likely flourish
    public stay peak health consciousness overcapacity likely occur consumer enthusiasm
    wane addition return fitness club industry high gaming industry said one analyst
    500 fitness club excluding club run profit organization according association
    physical fitness center estimate billion dlr year industry asked anyone offered
    buy unit nation 's largest health club chain peltier said one money offer buy
    fitness industry fragmented industry leader great opportunity growth acquisition
    standardization said wayne lachapelle chief financial officer livingwell inc lt
    well nation 's second largest fitness chain operator whih lachapelle said livingwell
    always interested acquisition opportunity could afford acquisition size bally
    time
  - gordon make bid acquire pagecorp lt pgoa lt gordon investment corp said plan make
    offer acquire pagecorp inc 's class class share 25 dlrs cash per share bid conditional
    upon examination gordon business affair pagecorp 45 day ending december 1987 proposed
    offer would condition upon ainimum number share tendered gordon said say minimum
    meanwhile pagecorp said agreed grant gordon option purchaser 900 000 class share
    25 dlrs per share exercisable gordon make acquisition bid december 1987 third
    party begin takeover december 31 1987 pagecorp also said class shareholder agreed
    deposit class share gordon proceeds offer
  - investment firm stake mcgill mftg lt mgll group affiliated investment firm led
    bermuda based fidelity international ltd boston based fmr corp told security exchange
    commission raised stake mcgill manufacturing co inc group said raised stake 88
    580 share pct total outstanding common stock buying 14 135 mcgill common share
    jan 19 march price ranging 33 57 34 57 dlrs share
- source_sentence: royal business group inc lt roy 2nd qtr march one shr 49 ct v five
    ct shr diluted 45 ct v five ct net 651 000 v 95 000 rev given 1st half shr 57
    ct v one ct shr diluted 53 ct v one ct net 781 000 v 56 000 rev given note current
    year net period includes gain 873 000 dlrs repurchase security result exclude
    business form division sold
  sentences:
  - royal business group inc lt roy 2nd qtr march one shr 49 ct v five ct shr diluted
    45 ct v five ct net 651 000 v 95 000 rev given 1st half shr 57 ct v one ct shr
    diluted 53 ct v one ct net 781 000 v 56 000 rev given note current year net period
    includes gain 873 000 dlrs repurchase security result exclude business form division
    sold
  - usda spring potato estimate agriculture department estimated 1987 spring potato
    production based april condition 19 267 000 cwt 100 lb v 19 822 000 cwt indicated
    last year department estimated spring potato area harvest 79 100 acre v 76 700
    acre estimated last month 75 900 acre harvested last year spring potato yield
    per harvested acre forecast 244 cwt per acre v 261 cwt per acre year ago usda
    said
  - marion lab lt mkc vote split dividend hike marion laboratory inc said board declared
    two one common stock split form dividend distribution april 21 record march 25
    board also said intends increase regular quarterly dividend 43 pct five ct share
    reflecting split said increase declared may 1987 board meeting reflected regular
    payment beginning july 1987
- source_sentence: tcby enterprise inc lt tcby 1st qtr feb 28 net shr eight ct v five
    ct net 370 898 v 823 988 sale 786 730 v 383 825 avg shrs 17 744 333 v 17 071 236
    note per share amount adjusted three two stock split april july 1986
  sentences:
  - feedgrain 92 supporter evaluate position advocate 92 plan feedgrains likely delay
    offering proposal disaster aid bill house agriculture committee scaled back include
    1987 winter wheat congressional source said disaster aid bill introduced rep glenn
    english okla sparked sharp controversy proposal implement 92 program 1987 wheat
    1988 winter wheat agreement reached trim bill back 1987 wheat supporter 92 feedgrains
    plan said even scaled version would equitable farmer unless english bill pertains
    1987 winter wheat simple disaster payment feedgrains treated equally said bill
    narrowed winter wheat supporter 92 feedgrains amendment probably offer proposal
    next week source said english agreed support amendment rep charles stenholm tex
    narrow bill 1987 wheat whether would also back reduction unclear agricultural
    aide english said congressman 's first choice make option available 1987 wheat
    farmer however political reality disaster aid winter wheat farmer would unavailable
    controversy spring wheat english might consider even greater cutback bill said
    92 plan farmer could forego planting still receive 92 pct deficiency payment rep
    arlan stangeland minn harold volkmer mo expressed interest expanding english bill
    include 92 program feedgrains aide said stangeland want reopen farm bill fair
    crop small percentage spring wheat farmer would likely sign 92 since incentive
    plant greater idle land economist said opponent 92 feedgrains program argue premature
    make major change farm bill house agriculture committee need study closely impact
    program
  - tcby enterprise inc lt tcby 1st qtr feb 28 net shr eight ct v five ct net 370
    898 v 823 988 sale 786 730 v 383 825 avg shrs 17 744 333 v 17 071 236 note per
    share amount adjusted three two stock split april july 1986
  - madrid metro halted spanish strike spread estimated mln metro user madrid stranded
    today striking railway worker halted underground transport system industry source
    said striker joined coal miner steel oil refinery worker spain 's latest wave
    stoppage wage demand 10 000 pitman northern province leon entered second day indefinite
    stoppage demand wage rise five day working week source said oil refinery worker
    picketed state owned empresa nacional de petroleo sa emp prevent fuel lorry leaving
    company 's largest plant puertollano central spain paramilitary police guarding
    steel mill reinosa northern spain daily protest planned job cut local government
    official said police force would remain place temper cooled 60 people injured
    pitched battle police steel foundry worker reinosa last month
- source_sentence: concord fabric inc lt ci 3rd qtr oper net period ended may 31 oper
    shr 31 ct v 29 ct oper net 552 035 v 525 729 sale 36 mln v 29 mln nine mths oper
    shr 08 dlrs v 04 dlrs oper net 931 488 v 864 075 sale 104 mln v 87 mln note 1986
    period ended june one note earnings exclude gain disposal discontinued operation
    162 000 dlrs nine ct share v loss 585 175 dlrs 33 ct share quarter gain 432 000
    dlrs 24 ct share v loss 585 175 dlrs 33 ct share nine month 1986 earnings exclude
    loss discontinued operation 111 024 dlrs six ct share quarter 237 773 dlrs 13
    ct share nine month
  sentences:
  - concord fabric inc lt ci 3rd qtr oper net period ended may 31 oper shr 31 ct v
    29 ct oper net 552 035 v 525 729 sale 36 mln v 29 mln nine mths oper shr 08 dlrs
    v 04 dlrs oper net 931 488 v 864 075 sale 104 mln v 87 mln note 1986 period ended
    june one note earnings exclude gain disposal discontinued operation 162 000 dlrs
    nine ct share v loss 585 175 dlrs 33 ct share quarter gain 432 000 dlrs 24 ct
    share v loss 585 175 dlrs 33 ct share nine month 1986 earnings exclude loss discontinued
    operation 111 024 dlrs six ct share quarter 237 773 dlrs 13 ct share nine month
  - woodside petroleum ltd lt wpla 1986 year shr nil v final yr div nil v pre tax
    pre minority loss 53 mln dlrs v profit 17 40 mln net attributable loss 17 14 mln
    dlrs v loss 73 mln sale 220 84 mln v 173 50 mln income 17 77 mln v 12 02 mln shrs
    666 67 mln v note attributable net loss tax 10 04 mln dlrs v 18 59 mln interest
    82 36 mln v 65 94 mln depreciation 64 77 mln v 35 74 mln minority 57 mln v 55
    mln net extraordinary loss 22 mln v loss 91 mln
  - hick haas group get financing spectradyne acquisition hick haas group get financing
    spectradyne acquisition
- source_sentence: bank japan intervenes buy dollar around 143 70 yen dealer bank
    japan intervenes buy dollar around 143 70 yen dealer
  sentences:
  - ec grant free market barley maize export european commission authorised export
    65 000 tonne free market barley today 's tender maximum rebate 138 75 european
    currency unit 55 000 tonne french maize 130 ecus grain trader said rejected bid
    breadmaking feed wheat said
  - health image inc lt himg 4th qtr loss shr loss one ct v loss seven ct net profit
    108 419 v loss 241 192 rev 044 882 v 317 266 year shr loss 18 ct v loss 23 ct
    net loss 430 027 v loss 432 982 rev 088 065 v 416 777 note share preferred dividend
  - bank japan intervenes buy dollar around 143 70 yen dealer bank japan intervenes
    buy dollar around 143 70 yen dealer
pipeline_tag: sentence-similarity
library_name: sentence-transformers
metrics:
- pearson_cosine
- spearman_cosine
model-index:
- name: SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2
  results:
  - task:
      type: semantic-similarity
      name: Semantic Similarity
    dataset:
      name: val
      type: val
    metrics:
    - type: pearson_cosine
      value: 0.9916250967357287
      name: Pearson Cosine
    - type: spearman_cosine
      value: 0.9297150928144825
      name: Spearman Cosine
---

# SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2). It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, text classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) <!-- at revision fa97f6e7cb1a59073dff9e6b13e2715cf7475ac9 -->
- **Maximum Sequence Length:** 256 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 256, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 384, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
  (2): Normalize()
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'bank japan intervenes buy dollar around 143 70 yen dealer bank japan intervenes buy dollar around 143 70 yen dealer',
    'bank japan intervenes buy dollar around 143 70 yen dealer bank japan intervenes buy dollar around 143 70 yen dealer',
    'health image inc lt himg 4th qtr loss shr loss one ct v loss seven ct net profit 108 419 v loss 241 192 rev 044 882 v 317 266 year shr loss 18 ct v loss 23 ct net loss 430 027 v loss 432 982 rev 088 065 v 416 777 note share preferred dividend',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

## Evaluation

### Metrics

#### Semantic Similarity

* Dataset: `val`
* Evaluated with [<code>EmbeddingSimilarityEvaluator</code>](https://sbert.net/docs/package_reference/sentence_transformer/evaluation.html#sentence_transformers.evaluation.EmbeddingSimilarityEvaluator)

| Metric              | Value      |
|:--------------------|:-----------|
| pearson_cosine      | 0.9916     |
| **spearman_cosine** | **0.9297** |

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 1,000 training samples
* Columns: <code>sentence_0</code>, <code>sentence_1</code>, and <code>label</code>
* Approximate statistics based on the first 1000 samples:
  |         | sentence_0                                                                         | sentence_1                                                                          | label                                                          |
  |:--------|:-----------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|:---------------------------------------------------------------|
  | type    | string                                                                             | string                                                                              | float                                                          |
  | details | <ul><li>min: 8 tokens</li><li>mean: 99.11 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 8 tokens</li><li>mean: 105.25 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 0.0</li><li>mean: 0.47</li><li>max: 1.0</li></ul> |
* Samples:
  | sentence_0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | sentence_1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | label            |
  |:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------------|
  | <code>new dutch advance total billion guilder dutch central bank said accepted bid totalling billion guilder tender new seven day special advance pct covering period march aimed relieving money market tightness subscription 300 mln guilder met full amount 300 mln 50 pct new facility replaces old five day advance worth billion guilder rate dealer expect week 's money market shortage around 12 billion guilder</code>                                                                                                                                                                                                                                                                                                                                                                                                         | <code>argentine grain shipping situation one grain vessel awaiting berth bahia blanca four buenos aire five rosario march 31 national grain board figure show situation port follows giving number ship loading awaiting berth expected respectively bahia blanca buenos aire rosario tonnage grain oilseed loaded onto ship loading awaiting berth expected port follows bahia blanca wheat 161 360 buenos aire maize 104 304 wheat 14 330 rosario wheat 50 400 maize 157 040 subproducts 50 100 sunflowerseed 000 millet 100</code>                                                                                                                                                                                                                                                                                                     | <code>0.0</code> |
  | <code>centel lt cnt see lower first qtr profit centel corp said see 1987 first quarter result 1986 due regulatory limit telephone earnings 15 ct 20 ct share dilution 1986 acquisition annual report chairman robert reuss told shareholder telephone profit continued limited ceiling imposed regulator well deregulation structural change within industry slowed growth investment base setting rate first quarter 1987 result last year 's first quarter 11 dlrs share said several company 's telephone unit may faced reduction rate return authorized regulator reuss said could result rate reduction refund customer reuss said encouraged prospect progress centel 's business communication cable television cellular telephone unit centel asking shareholder annual meeting approve tripling 120 mln authorized share</code> | <code>centel lt cnt see lower first qtr profit centel corp said see 1987 first quarter result 1986 due regulatory limit telephone earnings 15 ct 20 ct share dilution 1986 acquisition annual report chairman robert reuss told shareholder telephone profit continued limited ceiling imposed regulator well deregulation structural change within industry slowed growth investment base setting rate first quarter 1987 result last year 's first quarter 11 dlrs share said several company 's telephone unit may faced reduction rate return authorized regulator reuss said could result rate reduction refund customer reuss said encouraged prospect progress centel 's business communication cable television cellular telephone unit centel asking shareholder annual meeting approve tripling 120 mln authorized share</code> | <code>1.0</code> |
  | <code>gabelli firm 28 pct stake digiorgio corp may seek control gabelli firm 28 pct stake digiorgio corp may seek control</code>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | <code>gabelli firm 28 pct stake digiorgio corp may seek control gabelli firm 28 pct stake digiorgio corp may seek control</code>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | <code>1.0</code> |
* Loss: [<code>CosineSimilarityLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#cosinesimilarityloss) with these parameters:
  ```json
  {
      "loss_fct": "torch.nn.modules.loss.MSELoss"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `eval_strategy`: steps
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: steps
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 8
- `per_device_eval_batch_size`: 8
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `torch_empty_cache_steps`: None
- `learning_rate`: 5e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1
- `num_train_epochs`: 3
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.0
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: False
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: None
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `include_for_metrics`: []
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `dispatch_batches`: None
- `split_batches`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `use_liger_kernel`: False
- `eval_use_gather_object`: False
- `average_tokens_across_devices`: False
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin

</details>

### Training Logs
| Epoch | Step | val_spearman_cosine |
|:-----:|:----:|:-------------------:|
| 0.8   | 100  | 0.9297              |


### Framework Versions
- Python: 3.12.9
- Sentence Transformers: 3.4.1
- Transformers: 4.49.0
- PyTorch: 2.6.0+cpu
- Accelerate: 1.4.0
- Datasets: 3.3.1
- Tokenizers: 0.21.0

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->